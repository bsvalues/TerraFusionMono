
import { json, redirect } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import fs from "fs/promises";
import path from "path";
import Markdown from "react-markdown";

export const loader = async () => {
  if (process.env.NODE_ENV !== "development") {
    throw redirect("/");
  }
  const filePath = path.resolve("./README.md");
  const content = await fs.readFile(filePath, "utf-8");
  return json({ content });
};

export default function DevDocs() {
  const { content } = useLoaderData<typeof loader>();
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">📘 IncomeValuationTracker Dev Guide</h1>
      <Markdown className="prose lg:prose-xl">{content}</Markdown>
    </div>
  );
}
