
# IncomeValuationTracker Patch Log

## ✅ Added
- `/app/routes/docs/dev.tsx`: Dynamic route to show God-tier dev guide
- `/app/components/AIDevBadge.tsx`: Floating badge link to dev docs
- `README.md`: AI-ready Remix dev documentation

## 🔧 To Update
- In `app/root.tsx`:
  - Add: `import { AIDevBadge } from "~/components/AIDevBadge";`
  - Insert: `<AIDevBadge />` before `</body>`
  - Add nav link to `/docs/dev` visible only in dev mode

## 📌 Access Dev Guide
Visit `/docs/dev` in development mode. AI Agents are guided from there.
